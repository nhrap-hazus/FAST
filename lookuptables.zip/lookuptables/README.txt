DDFs and other tables were obtained from Hazus 4.0 SQL database

We verified that no additions, changes, or deletions to the DDFs occurred in Hazus 3.1, 3.2, and 4.0.

We stripped out trailing spaces from fields containing the Occupancy Class.


